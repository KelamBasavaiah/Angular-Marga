﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ManagerMVCProject.Models;
using ProjectModelProject;
using DeveloperBLProject;

namespace ManagerMVCProject.Controllers
{
    public class DeveloperController : Controller
    {
        // GET: Developer
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult About()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }
        [Authorize]
        //print the projects with projectid,name and description
        public ActionResult PrintProjects()
        {
            try
            {
                ViewBag.DeveloperId = Session["d_I"].ToString();
                DeveloperBL bl = new DeveloperBL();
                Manager manager = new Manager();
                manager.DeveloperId = ViewBag.DeveloperId;
                ProjectModel model = new ProjectModel();
                string developerId = manager.DeveloperId;
                List<ProjectModel> projectList = bl.GetAllProjectsFromManager(developerId);
                List<Manager> projects = new List<Manager>();
                Manager project;
                foreach (ProjectModel item in projectList)
                {
                    project = new Manager();
                    project.ProjectId = item.ProjectId;
                    project.ProjectName = item.ProjectName;
                    project.ProjectDescription = item.ProjectDescription;
                    projects.Add(project);
                }

                return View(projects);
            }
            catch(UserDefinedException ude)
            {
                ViewBag.Message = ude.Message;
                return View();
            }
            catch(Exception e)
            {
                ViewBag.Mesage = "Something went wrong..Please try Again!";
                return View();
            }
           

        }
        [HttpPost]

        public ActionResult PrintProjects(Manager manager)
        {
            TempData["Id"] = manager.ProjectId;
            string Id= TempData["Id"].ToString();
            return PrintModules(Id);

        }
        
        public ActionResult PrintModules(string Id)
        {
            try
            {
                DeveloperBL bl = new DeveloperBL();
                List<ProjectModel> moduleList = bl.GetAllTModulesForProject(Id);
                List<Manager> modules = new List<Manager>();
                Manager manager;
                foreach (ProjectModel item in moduleList)
                {
                    manager = new Manager();
                    manager.ModuleId = item.ModuleId;
                    manager.ModuleName = item.ModuleName;
                    manager.ModuleDescription = item.ModuleDescription;
                    modules.Add(manager);
                }
                return View(modules);
            }
            catch (UserDefinedException ude)
            {
                ViewBag.Message = ude.Message;
                return View();
            }
            catch (Exception e)
            {
                ViewBag.Mesage = "Something went wrong..Please try Again!";
                return View();
            }
        
        }
        [HttpPost]
        //Prints the modules to be developed for a unique project with module id,name and description
        public ActionResult PrintModules(Manager manager)
        {
            TempData["ModuleId"] = manager.ModuleId;            
            string moduleId = "";
            moduleId = TempData["ModuleId"].ToString();
            return UpdateStatus(moduleId);
        }
        
        public ActionResult UpdateStatus(string Id)
        {
            TempData["moduleId"] = Id;           
            return View();
        }
        //developer updates module status to the Manager
        [HttpPost]
        public ActionResult UpdateStatus(Manager manager)
        {
            try
            {
                string modulestatus = manager.ModuleStatus;
                ProjectModel developer = new ProjectModel();
                developer.ModuleStatus = modulestatus;
                developer.ModuleId = TempData["moduleId"].ToString();
                DeveloperBL bl = new DeveloperBL();

                if (bl.UpdateModuleStatustoManager(developer))
                {
                    ViewBag.Message = "Successfully Updated";

                }
                else
                {
                    ViewBag.Message = "Not  Updated";

                }
                return View();
            }
            catch (Exception e)
            {
                ViewBag.Mesage = "Something went wrong..Please try Again!";
                return View();
            }

        }
        //Developer get all bug details with bugid,moduleid,modulename and module description to clear bug
        public ActionResult GetAllBugs()
        {
            try
            {
                string developerId = Session["d_I"].ToString();
                DeveloperBL bl = new DeveloperBL();
                List<ProjectModel> bugList = bl.GetAllBug(developerId);
                List<Manager> bugs = new List<Manager>();
                Manager bug;
                foreach (ProjectModel item in bugList)
                {
                    bug = new Manager();
                    bug.BugId = item.BugId;
                    bug.ModuleId = item.ModuleId;
                    bug.BugDetails = item.BugDetails;
                    bugs.Add(bug);
                }
                return View(bugs);
            }
            catch (UserDefinedException ude)
            {
                ViewBag.Message = ude.Message;
                return View();
            }
            catch (Exception e)
            {
                ViewBag.Mesage = "Something went wrong..Please try Again!";
                return View();
            }



        }
        [HttpPost]
        public ActionResult GetAllBugs(Manager bugs)
        {

            TempData["Bug_Id"] = bugs.BugId;
            String bugid = "";
            bugid= TempData["Bug_Id"].ToString();
           
            return GetBugModules(bugid);
        }
        
        public ActionResult GetBugModules(string bug_id)
        {
            try
            {
                ViewBag.Message = bug_id;
                string bugId = "B001";
                DeveloperBL bl = new DeveloperBL();
                List<ProjectModel> moduleList = bl.GetAllBugModules(bugId);
                List<Manager> modules = new List<Manager>();
                Manager module;
                foreach (ProjectModel item in moduleList)
                {
                    module = new Manager();
                    module.ModuleId = item.ModuleId;
                    module.ModuleName = item.ModuleName;
                    module.ModuleDescription = item.ModuleDescription;
                    modules.Add(module);
                }
                return View(modules);
            }
            catch (UserDefinedException ude)
            {
                ViewBag.Message = ude.Message;
                return View();
            }
            catch (Exception e)
            {
                ViewBag.Mesage = "Something went wrong..Please try Again!";
                return View();
            }


          
        }
        //Get Bug modules using bugid with moduleid,modulename and module description
        [HttpPost]
        public ActionResult GetBugModules(Manager bugs)
        {
            TempData["bug_id"] = bugs.BugId;

            return View();
        }
        public ActionResult GetBugStatusFromTester()
        {
            try
            {
                string developerId = Session["d_I"].ToString();
                DeveloperBL bl = new DeveloperBL();
                List<ProjectModel> bugStatusFromTester = bl.GetBugStatusFromTester(developerId);
                List<Manager> bug = new List<Manager>();
                Manager manager;
                foreach (ProjectModel item in bugStatusFromTester)
                {
                    manager = new Manager();
                    manager.BugId = item.BugId;
                    manager.BugStatus = item.BugStatus;
                    bug.Add(manager);
                }
                return View(bug);
            }
            catch (UserDefinedException ude)
            {
                ViewBag.Message = ude.Message;
                return View();
            }
            catch (Exception e)
            {
                ViewBag.Mesage = "Something went wrong..Please try Again!";
                return View();
            }

        }
        [HttpPost]
        public ActionResult GetBugStatusFromTester(string id)
        {
            return View("UpdateBugStatusToTester");
        }
        public ActionResult UpdateBugStatusToTester(string id)
       {
            TempData["bugId"] = id;
            ViewBag.Message = "hii";
            return View();

       }
        //Developer updates bug status to tester using bug id
        [HttpPost]
        public ActionResult UpdateBugStatusToTester(Manager manager)
        {
            try
            {
                string bugstatus = manager.BugStatus;
                ProjectModel developer = new ProjectModel();
                developer.BugStatus = bugstatus;
                developer.BugId = TempData["bugId"].ToString();
                DeveloperBL bl = new DeveloperBL();

                if (bl.UpdateBugStatusToTester(developer))
                {
                    ViewBag.Message = "Successfully bug status Updated";

                }
                else
                {
                    ViewBag.Message = "Bug status cannot be Updated";

                }
                return View();
            }
            catch (Exception e)
            {
                ViewBag.Mesage = "Something went wrong..Please try Again!";
                return View();
            }

        }
        //Get bug status from tester 
    



    }






}
