﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProjectManagerBLProject;
using ProjectModelProject;
using ManagerMVCProject.Models;

namespace ManagerMVCProject.Controllers
{
    public class ManagerController : Controller
    {
        // GET: Manager
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult About()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }
        [Authorize]
        //Print rojects in a list with project id,name and description
        public ActionResult ProjectDisplay()
        {
            try
            {
                ViewBag.ManagerId = Session["m_I"].ToString();

                ProjectManagerBL bl = new ProjectManagerBL();
                Manager manager = new Manager();
                manager.ManagerId = ViewBag.ManagerId;
                ProjectModel model = new ProjectModel();
                model.ManagerId = manager.ManagerId;
                List<ProjectModel> projectList = bl.GetAllProjects(model);
                List<Manager> projects = new List<Manager>();
                Manager manager1;
                foreach (ProjectModel item in projectList)
                {
                    manager1 = new Manager();
                    manager1.ProjectId = item.ProjectId;
                    manager1.ProjectName = item.ProjectName;
                    manager1.ProjectDescription = item.ProjectDescription;
                    projects.Add(manager1);
                }
                return View(projects);
            }
            catch (UserDefinedException ude)
            {
                ViewBag.Message = ude.Message;
                return View();

            }
            catch (Exception e)
            {
                ViewBag.Message = "Something went wrong..Please try Again!";
                return View();

            }
        }
        [HttpPost]
        public ActionResult ProjectDisplay(Manager manager)
        {
            TempData["Id"] = manager.ProjectId;
            string Id = "";
            Id = TempData["Id"].ToString();
            return ModulesDisplay(Id);                      
        }
        //Print All modules when a particular project selected
        public ActionResult ModulesDisplay(string Id)
        {
            try
            {
                ProjectManagerBL bl = new ProjectManagerBL();
                List<ProjectModel> moduleList = bl.GetAllTModulesForProject(Id);
                List<Manager> modules = new List<Manager>();
                Manager manager;
                foreach (ProjectModel item in moduleList)
                {
                    manager = new Manager();
                    manager.ModuleId = item.ModuleId;
                    manager.ModuleName = item.ModuleName;
                    manager.ModuleDescription = item.ModuleDescription;
                    modules.Add(manager);
                }
                return View(modules);
            }
            catch (UserDefinedException ude)
            {
                ViewBag.Message = ude.Message;
                return View();

            }
            catch (Exception e)
            {
                ViewBag.Message = "Something went wrong..Please try Again!";
                return View();

            }


        }
        [HttpPost]
        public ActionResult ModulesDisplay()
        {


            return View();
        }
        //Displays developer details in a list along with developer id to assign modules
        public ActionResult DisplayDeveloper()
        {
            try
            {
                ProjectManagerBL bl = new ProjectManagerBL();
                List<ProjectModel> developerlist = bl.GetAllDevelopers();
                List<Manager> developers = new List<Manager>();
                Manager developer;
                foreach (ProjectModel item in developerlist)
                {
                    developer = new Manager();
                    developer.DeveloperId = item.DeveloperId;
                    developers.Add(developer);
                }
                return View(developers);
            }
            catch (UserDefinedException ude)
            {
                ViewBag.Message = ude.Message;
                return View();

            }
            catch (Exception e)
            {
                ViewBag.Message = "Something went wrong..Please try Again!";
                return View();

            }

        }
        [HttpPost]
        public ActionResult DisplayDeveloper(string id)
        {

            //return AssignModuleToDeveloper(developer.DeveloperId);
            return View("AssignModuleToDeveloper");
        }
       
        public ActionResult AssignModuleToDeveloper(string id)
        {
            TempData["DeveloperId"] = id;
            ViewBag.message = "";
            return View();

        }
        [HttpPost]
        //Assign modules to developer with a unique developer id and message if modules assigned are successful
        public ActionResult AssignModuleToDeveloper(Manager manager)
        {
            try
            {
                ProjectManagerBL bl = new ProjectManagerBL();
                ProjectModel developer = new ProjectModel();
                developer.DeveloperId = TempData["DeveloperId"].ToString();
                developer.ModuleId = manager.ModuleId;
                if (bl.AssignModuleToDeveloper(developer))
                {
                    ViewBag.Message = "Modules Assigned to Developer Successfully!";
                }
                else
                {
                    ViewBag.Message = "Modules Not Assigned to Developer..Please Try Again!";
                }
                return View();

            }            
            catch (Exception e)
            {
                ViewBag.Message = "Something went wrong..Please try Again!";
                return View();

            }


        }

        //Display tester details in a list if there is a bug to be assigned to tester with a testerid
        public ActionResult DisplayTester()
        {
            try
            {
                ProjectManagerBL bl = new ProjectManagerBL();
                List<ProjectModel> testerlist = bl.GetAllTesters();
                List<Manager> testers = new List<Manager>();
                Manager tester;
                foreach (ProjectModel item in testerlist)
                {
                    tester = new Manager();
                    tester.TesterId = item.TesterId;
                    testers.Add(tester);
                }
                return View(testers);

            }
            catch (UserDefinedException ude)
            {
                ViewBag.Message = ude.Message;
                return View();

            }
            catch (Exception e)
            {
                ViewBag.Message = "Something went wrong..Please try Again!";
                return View();

            }





        }
        [HttpPost]
        public ActionResult DisplayTester(string id)
        {
            //TempData["TesterId"] = manager.TesterId;           
            //string testerId = "";
            //testerId = TempData["TesterId"].ToString();
            //return AssignModuleToTester(manager.TesterId);
            return View("AssignModuleToTester");
        }
        public ActionResult AssignModuleToTester(string id)
        {
            TempData["TesterId"] = id;
            
            
            return View();

        }
        [HttpPost]
        //Manager Assign modules to tester with a unique tester id
        public ActionResult AssignModuleToTester(Manager manager)
        {
            try
            {
                ProjectManagerBL bl = new ProjectManagerBL();
                ProjectModel tester = new ProjectModel();
                tester.TesterId = TempData["TesterId"].ToString();
                tester.ModuleId = manager.ModuleId;
                if (bl.AssignModuleToTester(tester))
                {
                    ViewBag.Message = "Modules Assigned to Tester Successfully!";
                }
                else
                {
                    ViewBag.Message = "Modules Not Assigned to Tester..Please Try Again!";
                }
                return View();
            }
            catch (Exception e)
            {
                ViewBag.Message = "Something went wrong..Please try Again!";
                return View();

            }



        }
        //Get Module status from with a moduleid
        public ActionResult GetModuleStatus()
        {
            try
            {
                Manager moduleStatus = new Manager();
                string module_id = "MO01";
                ProjectManagerBL bl = new ProjectManagerBL();
                String status = "";
                status = bl.GetModuleStatus(module_id);
                moduleStatus.ModuleStatus = status;
                return View(moduleStatus);
            }
            catch (Exception e)
            {
                ViewBag.Message = "Something went wrong..Please try Again!";
                return View();

            }

        }
    }
}