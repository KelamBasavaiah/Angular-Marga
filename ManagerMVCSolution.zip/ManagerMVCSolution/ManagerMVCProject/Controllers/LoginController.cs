﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LoginBLProject;
using ManagerMVCProject.Models;
using ProjectModelProject;
using System.Web.Security;

namespace ManagerMVCProject.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult signIn()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Signin(Manager user)
        {
            if (ModelState.IsValid)
            {
                LoginBL bl = new LoginBL();
                ProjectModel login = new ProjectModel();
                string role = bl.loging(user.EmployeeId, user.Password);

                if (role == "Manager")
                {
                    TempData["m_I"] = user.EmployeeId;
                    Session.Add("m_I", user.EmployeeId);
                    ViewBag.Message = "yes done";
                    FormsAuthentication.SetAuthCookie(Request.Form["EmployeeId"], true);
                    return this.RedirectToAction("Index", "Manager");

                }
                else if (role == "Tester")
                {
                    TempData["t_I"] = user.EmployeeId;
                    Session.Add("t_I", user.EmployeeId);
                    FormsAuthentication.SetAuthCookie(Request.Form["EmployeeId"], true);
                    return this.RedirectToAction("Index", "Tester");
                }
                else if (role == "Developer")
                {
                    TempData["d_I"] = user.EmployeeId;
                    Session.Add("d_I", user.EmployeeId);
                    FormsAuthentication.SetAuthCookie(Request.Form["EmployeeId"], true);
                    return this.RedirectToAction("Index", "Developer");
                }
                else
                {
                    ViewBag.Message = "Invalid Username or password";

                }
            }

            return View();
        }

        [Authorize]
        public ActionResult Clear()
        {

            FormsAuthentication.SignOut();
            Session.Abandon();


            HttpCookie cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, "");
            cookie1.Expires = DateTime.Now.AddYears(-1);
            Response.Cookies.Add(cookie1);


            return RedirectToAction("Signin", "Login");
        }
    }
}