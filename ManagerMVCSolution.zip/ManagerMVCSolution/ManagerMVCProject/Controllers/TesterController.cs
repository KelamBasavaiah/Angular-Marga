﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ManagerMVCProject.Models;
using TesterBLProject;
using ProjectModelProject;

namespace ManagerMVCProject.Controllers
{
    public class TesterController : Controller
    {
        // GET: Tester
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult About()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }
      [Authorize]
        //Displays projects to be tester
        public ActionResult PrintProjectsForTester()
        {
            ViewBag.TesterId = Session["t_I"].ToString();
            TesterBL bl = new TesterBL();
            Manager manager = new Manager();
            manager.TesterId = ViewBag.TesterId;
            ProjectModel model = new ProjectModel();
            string testerId = manager.TesterId;
            List<ProjectModel> projectList = bl.GetAllTesterProjects(testerId);
            List<Manager> projects = new List<Manager>();
            Manager manager1;
            foreach (ProjectModel item in projectList)
            {
                manager1 = new Manager();
                manager1.ProjectId = item.ProjectId;
                manager1.ProjectName = item.ProjectName;
                manager1.ProjectDescription = item.ProjectDescription;
                projects.Add(manager1);
            }

            return View(projects);
        }
        [HttpPost]


        public ActionResult PrintProjectsForTester(Manager manager)
        {
            try
            {
                TempData["Id"] = manager.ProjectId;
                //string Id = TempData["Id"].ToString();
                return PrintModulesForTester(manager.ProjectId);
            }
            catch(Exception e)
            {
                ViewBag.Message = "Something went wrong..Please try Again!";
                return View();
            }
           

        }

        //The moduleid ,modulename,module description is displayed according to a particular project 
        public ActionResult PrintModulesForTester(string Id)
        {
            try
            {
                TesterBL bl = new TesterBL();
                List<ProjectModel> moduleList = bl.GetAllTesterModules(Id);
                List<Manager> modules = new List<Manager>();
                Manager manager;
                foreach (ProjectModel item in moduleList)
                {
                    manager = new Manager();
                    manager.ModuleId = item.ModuleId;
                    manager.ModuleName = item.ModuleName;
                    manager.ModuleDescription = item.ModuleDescription;
                    modules.Add(manager);
                }
                return View(modules);
            }
            catch (UserDefinedException ude)
            {
                ViewBag.Message = ude.Message;
                return View();

            }
            catch (Exception e)
            {
                ViewBag.Message = "Something went wrong..Please try Again!";
                return View();

            }

         
        }
        [HttpPost]
        public ActionResult PrintModulesForTester(Manager manager)
        {
            try
            {
                TempData["ModuleId"] = manager.ModuleId;
                string moduleId = "";
                moduleId = TempData["ModuleId"].ToString();
                return UpdateStatusToManager(moduleId);
            }
            catch(Exception e)
            {
                ViewBag.Message = "Something went wrong..Please try Again!";
            }
            return View();
        
        }

        public ActionResult UpdateStatusToManager(string Id)
        {
            TempData["moduleId"] = Id;
            return View();
        }
        //Tester updates status to manager after successful completion of bug testing
        [HttpPost]
        public ActionResult UpdateStatusToManager(Manager manager)
        {
            try
            {
                string modulestatus = manager.ModuleStatus;
                ProjectModel tester = new ProjectModel();
                tester.ModuleStatus = modulestatus;
                tester.ModuleId = TempData["moduleId"].ToString();
                TesterBL bl = new TesterBL();

                if (bl.UpdateModuleTestedStatustoManager(tester))
                {
                    ViewBag.Message = "Successfully Updated";

                }
                else
                {
                    ViewBag.Message = "Not  Updated";

                }
            }
            catch(Exception e)
            {
                ViewBag.Message = "Something went wrong..Please try Again!";
            }
            
            return View();
        }
        public ActionResult CreateBug()
        {
            return View();
        }
        //Raise bugs when a bug is encountered
        [HttpPost]
        public ActionResult CreateBug(Manager bug) 
        {
            try
            {
                TesterBL bl = new TesterBL();
                ProjectModel bugDetail = new ProjectModel();
                bugDetail.BugId = bug.BugId;
                bugDetail.ModuleId = bug.ModuleId;
                bugDetail.BugDetails = bug.BugDetails;
                if (bl.CreateBug(bugDetail))
                {
                    ViewBag.Message = "Bug Created";
                }
                else
                {
                    ViewBag.Message = "Not Created";

                }
            } catch(Exception e)
            {
                ViewBag.Message = "Something went wrong..Please try Again!";
                
            }
            
            return View();
        }
        public ActionResult BugStatus()
        {
            
            return View();
        }
        //Updates bug status to developer
        [HttpPost]
        public ActionResult BugStatus(Manager manager)
        {
            try
            {
                string bugStatus = manager.BugStatus;
                ProjectModel bug = new ProjectModel();
                TesterBL bl = new TesterBL();
                bug.BugStatus = bugStatus;
                bug.BugId = manager.BugId;
                if (bl.UpdateBugStatusToDeveloper(bug))
                {
                    ViewBag.Message = "Updated";
                }
                else
                {
                    ViewBag.Message = "NotUpdated";
                }
            }
            catch(Exception e)
            {
                ViewBag.Message = "Something went wrong..Please try Again!";
               
            }

            return View();
        }
        //Bug status is recieved from developer using employee id
        public ActionResult GetBugStatusFromDeveloper()
       
        {
            try
            {
                string testerId = Session["t_I"].ToString();
                TesterBL bl = new TesterBL();
                List<ProjectModel> bugStatus = bl.GetBugStatusFromDeveloper(testerId);
                List<Manager> bug = new List<Manager>();
                Manager manager;
                foreach (ProjectModel item in bugStatus)
                {
                    manager = new Manager();
                    manager.BugId = item.BugId;
                    manager.BugStatus = item.BugStatus;
                    bug.Add(manager);
                }
                return View(bug);
            }
            catch(UserDefinedException ude)
            {
                ViewBag.Message = ude.Message;
                return View();

            }
            catch (Exception e)
            {
                ViewBag.Message = "Something went wrong..Please try Again!";
                return View();

            }



        }
    }




    
}