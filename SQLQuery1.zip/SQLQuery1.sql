﻿---Database----
create database dbEmployee
use dbEmployee


---Create Employee Table---
--create table tblEmployee(Id int identity primary key,EmployeeId as 'E' + right('000'+cast(Id as varchar),3)persisted not null unique,EmployeeName varchar(50),Email varchar(50),Mobile varchar(20),UserName varchar(50),Password varchar(50),confirmPassword varchar(50),Role varchar(50))
create table tblEmployee(EmployeeId varchar(10) constraint pk_employeeid primary key,EmployeeName varchar(50),Email varchar(50),Mobile varchar(20),UserName varchar(50),Password varchar(50),confirmPassword varchar(50),Role varchar(50))

select * from tblEmployee
insert into tblEmployee values('E001','vishnu','vishnu@gmail.com','9443343434','vishnu@gmail.com','vishnu@123','vishnu@123','Manager')
drop table tblEmployee

---Get all Employee---
create procedure proc_GetAllEmployee
as
begin
	select * from tblEmployee
end
exec proc_GetAllEmployee

---Insert Employee---
create procedure proc_InsertEmployee(@EmployeeId varchar(10),@EmployeeName varchar(50),@Email varchar(50),@Mobile varchar(20),@UserName varchar(50),@Password varchar(50),@confirmPassword varchar(50),@Role varchar(50))
as
begin
	insert into tblEmployee values(@EmployeeId,@EmployeeName,@Email,@Mobile,@UserName,@Password,@confirmPassword,@Role)
end

exec proc_InsertEmployee 'E002','vishnu','vishnu@gmail.com','9443343434','vishnu@gmail.com','vishnu@123','vishnu@123','Manager'

---Update Employee---
create Procedure proc_UpdateEmployee(@EmployeeId varchar(10),@EmployeeName varchar(50),@Email varchar (50),@Mobile varchar (20),@UserName varchar (50),@Password varchar(50),@confirmPassword varchar(50),@Role varchar(50))
as
begin
Update tblEmployee set EmployeeName=@EmployeeName,  
   Email=@Email,  
   Mobile=@Mobile,
   UserName=@UserName,
   Password=@Password,
   confirmPassword=@confirmPassword,
   Role=@Role
   where EmployeeId=@EmployeeId  
End  

exec proc_UpdateEmployee 'E001','Manivishnu','Manivishnu@gmail.com','9443343333','Manivishnu@gmail.com','Manivishnu@123','Manivishnu@123','Developer'

---Delete Employee---
delete from tblEmployee where EmployeeId='E001'

create procedure proc_DeleteEmployee(@EmployeeId varchar(10))
as
begin
	delete from tblEmployee where EmployeeId=@EmployeeId
end

exec proc_DeleteEmployee ''


select * from tblUser
----Admin table---
--create table tblAdmin(Id int identity primary key,AdminId as 'A' + right('000'+cast(Id as varchar),3)persisted not null unique,AdminName varchar(50),UserName varchar(50),Password varchar(50))
create table tblAdmin(AdminId varchar(10) constraint pk_adminid primary key,AdminName varchar(50),UserName varchar(50),Password varchar(50))
select * from tblAdmin
insert into tblAdmin values('A001','Admin','admin@gmail.com','admin123')

----Fetch password---
create procedure proc_Login(@UserName varchar(50),@Password varchar(50) out)
as
begin
	set @Password=(select Password from tblAdmin where UserName=@UserName)
end

-----Testing Procedures
declare 
@Password varchar (50)
exec proc_Login 'admin@gmail.com',@Password out
select @Password

---Edit---
select * from tblEmployee

select EmployeeName,Email,Mobile,UserName,Password,confirmPassword,Role from tblEmployee where EmployeeId='E001'

Alter proc proc_GetEditEmployeeData(@EmployeeId varchar(20))
as 
begin
select * from tblEmployee where EmployeeId=@EmployeeId
end

exec proc_GetEditEmployeeData 'E004'