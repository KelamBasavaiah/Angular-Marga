﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DeveloperDALProject;
using ProjectModelProject;
using System.Data;

namespace DeveloperBLProject
{
    public class DeveloperBL
    {
        DeveloperDAL dev_dal;
        public DeveloperBL()
        {
            dev_dal = new DeveloperDAL();
        }
        //Get projects from Manager in a list with projectid,name and description
        public List<ProjectModel> GetAllProjectsFromManager(string developerId)
        {
            List<ProjectModel> projects = new List<ProjectModel>();
            DataSet dsGetProject = dev_dal.GetAllProjectFromManager(developerId);
            ProjectModel project;
            foreach (DataRow row in dsGetProject.Tables[0].Rows)
            {
                project = new ProjectModel();
                project.ProjectId = row[0].ToString();
                project.ProjectName = row[1].ToString();
                project.ProjectDescription = row[2].ToString();
                projects.Add(project);
            }
            return projects;

        }
        //Get All modules assigned by manager 
        public List<ProjectModel> GetAllTModulesForProject(string id)
        {
            List<ProjectModel> modules = new List<ProjectModel>();
            DataSet dsGetModules = dev_dal.GetAllmodulesForProject(id);
            ProjectModel module;
            foreach (DataRow row in dsGetModules.Tables[0].Rows)
            {
                module = new ProjectModel();
                module.ModuleId = row[0].ToString();
                module.ModuleName = row[1].ToString();
                module.ModuleDescription = row[2].ToString();
                modules.Add(module);
            }
            return modules;
        }
        //update module status to manager on successful completion
        public bool UpdateModuleStatustoManager(ProjectModel tester)
        {
            return dev_dal.UpdateModuleStatustoManager(tester);
        }
        //Update bug status to tester when a bug is raised
        public bool UpdateBugStatusToTester(ProjectModel developer)
        {
            return dev_dal.UpdateBugStatusToTester(developer);
        }
        //Get bug status from tester if there is a bug in the module tested
        public List<ProjectModel> GetBugStatusFromTester(string developerId)
        {
            List<ProjectModel> bugStatus = new List<ProjectModel>();
            DataSet dsGetBugStatus = dev_dal.GetAllBugModules(developerId);
            ProjectModel bug ;
            foreach (DataRow row in dsGetBugStatus.Tables[0].Rows)
            {
                bug = new ProjectModel();
                bug.BugId = row[0].ToString();
                bug.BugStatus = row[1].ToString();
                bugStatus.Add(bug);
            }
            return bugStatus;

        }
        //Get All bugs in a list with bug id,module id,and bug details
        public List<ProjectModel> GetAllBug(string developerId)
        {
            List<ProjectModel> bugs = new List<ProjectModel>();
            DataSet dsGetBugDetails = dev_dal.GetBugDetails(developerId);
            ProjectModel bug;
            foreach (DataRow row in dsGetBugDetails.Tables[0].Rows)
            {
                bug = new ProjectModel();
                bug.BugId= row[0].ToString();
                bug.ModuleId = row[1].ToString();
                bug.BugDetails = row[2].ToString();
                bugs.Add(bug);
            }
            return bugs;
        }
        //get bug modules to clear bugs with module id,module name,module desciption
        public List<ProjectModel> GetAllBugModules(string bug_id)
        {
            List<ProjectModel> modules = new List<ProjectModel>();
            DataSet dsGetBugModules = dev_dal.GetAllBugModules(bug_id);
            ProjectModel module;
            foreach (DataRow row in dsGetBugModules.Tables[0].Rows)
            {
                module = new ProjectModel();
                module.ModuleId = row[0].ToString();
                module.ModuleName = row[1].ToString();
                module.ModuleDescription = row[2].ToString();
                modules.Add(module);
            }
            return modules;
        }


    }
}
