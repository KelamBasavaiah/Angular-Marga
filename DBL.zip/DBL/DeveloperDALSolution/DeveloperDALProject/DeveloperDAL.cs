﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ProjectModelProject;

namespace DeveloperDALProject
{
    public class DeveloperDAL
    {
        SqlConnection conn;
        SqlCommand  cmdUpdatemoduleStatus, cmdUpdateBugStatus, cmdGetBugStatus,cmdGetAllProjects,cmdGetAllModules,cmdGetBugDetails, cmdGetBugModules;
        SqlDataAdapter daGetProject, daGetModules,daGetBugDetails, daGetBugModules,daGetBugStatus;
        public DeveloperDAL()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conUser"].ConnectionString);
        }
        //get all projects from manager with developer id
        public DataSet GetAllProjectFromManager(string developerId)
        {
            cmdGetAllProjects = new SqlCommand("proc_GetAllProjectForDeveloper", conn);
            cmdGetAllProjects.Parameters.AddWithValue("@developerId",developerId);
            DataSet dsGetProject = new DataSet();
            daGetProject = new SqlDataAdapter(cmdGetAllProjects);
            daGetProject.SelectCommand.CommandType = CommandType.StoredProcedure;
            daGetProject.Fill(dsGetProject);
            return dsGetProject;
        }
        //Get All modules for a particular project assigned by Manager
        public DataSet GetAllmodulesForProject(string id)
        {
            cmdGetAllModules = new SqlCommand("proc_GetAllModulesForDeveloper", conn);
            DataSet dsGetModules = new DataSet();
            cmdGetAllModules.Parameters.AddWithValue("@ProjectId", id);
            daGetModules = new SqlDataAdapter(cmdGetAllModules);
            daGetModules.SelectCommand.CommandType = CommandType.StoredProcedure;
            daGetModules.Fill(dsGetModules);
            return dsGetModules;
        }
        //Updates module status to manager when all modules are completed successfully 
        public bool UpdateModuleStatustoManager(ProjectModel developer)
        {
            bool updatedModuleStatus = false;
            cmdUpdatemoduleStatus = new SqlCommand("proc_UpdateModuleStatusToManagerFromDeveloper",conn);
            cmdUpdatemoduleStatus.Parameters.AddWithValue("@moduleId", developer.ModuleId);
            cmdUpdatemoduleStatus.Parameters.AddWithValue("@moduleStatus", developer.ModuleStatus);
            cmdUpdatemoduleStatus.CommandType = CommandType.StoredProcedure;
            if (conn.State == ConnectionState.Open)
                conn.Close();
            conn.Open();
            if (cmdUpdatemoduleStatus.ExecuteNonQuery() > 0)
            {
                updatedModuleStatus = true;
            }
            return updatedModuleStatus;
        }
        //Updates bug status to tester after clearing bugs raised by tester
        public bool UpdateBugStatusToTester(ProjectModel developer)
        {
            bool updatedBugStatus = false;
            cmdUpdateBugStatus = new SqlCommand("proc_UpdateBugStatusToTester",conn);
            cmdUpdateBugStatus.Parameters.AddWithValue("@bug_Id", developer.BugId);
            cmdUpdateBugStatus.Parameters.AddWithValue("@bugStatus", developer.BugStatus);
            cmdUpdateBugStatus.CommandType = CommandType.StoredProcedure;
            if (conn.State == ConnectionState.Open)
                conn.Close();
            conn.Open();
            if (cmdUpdatemoduleStatus.ExecuteNonQuery() > 0)
            {
                updatedBugStatus = true;
            }
            return updatedBugStatus;

        }
        //Get bug status from tester when a bug is raised
        public DataSet GetBugStatusFromTester(string developerId)
        {
            
            cmdGetBugStatus = new SqlCommand("proc_GetBugStatusFromTester",conn);
            DataSet dsGetBugStatus = new DataSet();
            cmdGetBugStatus.Parameters.AddWithValue("@developer_Id", developerId);
            daGetBugStatus = new SqlDataAdapter(cmdGetBugStatus);
            daGetBugStatus.SelectCommand.CommandType = CommandType.StoredProcedure;
            daGetBugStatus.Fill(dsGetBugStatus);
            return dsGetBugStatus;
            
            
        }
        //get bug details from tester with developerid of that module 
        public DataSet GetBugDetails(string developerId)
        {
            cmdGetBugDetails = new SqlCommand("proc_GetBugDetails", conn);
            cmdGetBugDetails.Parameters.AddWithValue("@developerId", developerId);
            DataSet dsGetBugDetails = new DataSet();
            daGetBugDetails = new SqlDataAdapter(cmdGetBugDetails);
            daGetBugDetails.SelectCommand.CommandType = CommandType.StoredProcedure;
            daGetBugDetails.Fill(dsGetBugDetails);
            return dsGetBugDetails;

        }
        //get bug modules with bugid from Tester to be tested
        public DataSet GetAllBugModules(string id)
        {
            cmdGetBugModules = new SqlCommand("proc_GetBugModules", conn);
            DataSet dsGetBugModules = new DataSet();
            cmdGetBugModules.Parameters.AddWithValue("@bug_id", id);
            daGetBugModules = new SqlDataAdapter(cmdGetBugModules);
            daGetBugModules.SelectCommand.CommandType = CommandType.StoredProcedure;
            daGetBugModules.Fill(dsGetBugModules);
            return dsGetBugModules;
        }


    }
}
