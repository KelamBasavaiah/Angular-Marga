﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TesterModelProject
{
    public class TesterModel
    {
        string testerId, bugId, bugDescription, moduleId, moduleStatus, bugStatus;

        public string TesterId { get => testerId; set => testerId = value; }
        public string BugId { get => bugId; set => bugId = value; }
        public string BugDescription { get => bugDescription; set => bugDescription = value; }
        public string ModuleId { get => moduleId; set => moduleId = value; }
        public string ModuleStatus { get => moduleStatus; set => moduleStatus = value; }
        public string BugStatus { get => bugStatus; set => bugStatus = value; }
    }
}
