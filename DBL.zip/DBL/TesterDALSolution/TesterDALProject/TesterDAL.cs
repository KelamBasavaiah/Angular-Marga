﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ProjectModelProject;

namespace TesterDALProject
{
    public class TesterDAL
    {
        SqlConnection conn;
        SqlCommand cmdUpdatemoduleStatus,cmdUpdateBugStatus,cmdGetBugFixedModuleStatus,cmdGetAllProjects,cmdCreateBug,cmdGetAllModules,cmdGetBugDetails,cmdGetAllBugModulesForTester;
        SqlDataAdapter daGetProject, daGetModules,daGetBugDetails,daGetAllModulesForTester,daGetBugStatus;
        public TesterDAL()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conUser"].ConnectionString);
        }
        //Tester gets All projects from manager using unique tester id 
        public DataSet GetAllProjectFromManager(string testerId)
        {
            cmdGetAllProjects = new SqlCommand("proc_GetAllProject", conn);
            DataSet dsGetProject = new DataSet();
            cmdGetAllProjects.Parameters.AddWithValue("@testerId", testerId);
            daGetProject = new SqlDataAdapter(cmdGetAllProjects);
            daGetProject.SelectCommand.CommandType = CommandType.StoredProcedure;
            daGetProject.Fill(dsGetProject);
            return dsGetProject;
        }
        // Modules are assigned to tester for a particular project to be tested
        public DataSet GetAllmodulesForProject(string projectId)
        {
            cmdGetAllModules = new SqlCommand("proc_GetAllModules", conn);
            DataSet dsGetModules = new DataSet();
            cmdGetAllModules.Parameters.AddWithValue("@ProjectId", projectId);
            daGetModules = new SqlDataAdapter(cmdGetAllModules);
            daGetModules.SelectCommand.CommandType = CommandType.StoredProcedure;
            daGetModules.Fill(dsGetModules);
            return dsGetModules;
        }
        /*If there is a bug in the module which is tested tester raise a bug using 
          bugid,moduleid which is tested and bug description to explain the type of bug*/
        public bool CreateBug(ProjectModel bugValues)
        {
            bool bugCreatedStatus = false;
            cmdCreateBug = new SqlCommand("proc_CreateBug",conn);
            cmdCreateBug.Parameters.AddWithValue("@bugId",bugValues.BugId);
            cmdCreateBug.Parameters.AddWithValue("@ModuleId",bugValues.ModuleId);
            cmdCreateBug.Parameters.AddWithValue("@BugDescription",bugValues.BugDetails);
            cmdCreateBug.CommandType = CommandType.StoredProcedure;
            if (conn.State == ConnectionState.Open)
                conn.Close();
            conn.Open();
            if (cmdCreateBug.ExecuteNonQuery() > 0)
            {
                bugCreatedStatus = true;
            }
            return bugCreatedStatus;


        }
        //Tester updates the success module status to Manager with testerid and status of the module
        public bool UpdateModuleTestedStatustoManager(ProjectModel tester)
        {
            bool updatedModuleStatus = false;
            cmdUpdatemoduleStatus = new SqlCommand("proc_UpdateModuleStatusToManager",conn);
            cmdUpdatemoduleStatus.Parameters.AddWithValue("@moduleId",tester.ModuleId);
            cmdUpdatemoduleStatus.Parameters.AddWithValue("@moduleStatus",tester.ModuleStatus);
            cmdUpdatemoduleStatus.CommandType = CommandType.StoredProcedure;
            if (conn.State == ConnectionState.Open)
                conn.Close();
            conn.Open();
            if (cmdUpdatemoduleStatus.ExecuteNonQuery() > 0)
            {
                updatedModuleStatus = true;
            }
            return updatedModuleStatus;
        }
        //Tester updates bug status to developer if there is a bug raised to be solved
        public bool UpdateBugStatusToDeveloper(ProjectModel tester)
        {
            bool updatedBugStatus = false;
            cmdUpdateBugStatus = new SqlCommand("proc_UpdateBugStatusToDeveloper",conn);
            cmdUpdateBugStatus.Parameters.AddWithValue("@bugId",tester.BugId);
            cmdUpdateBugStatus.Parameters.AddWithValue("@bugStatus",tester.BugStatus);
            cmdUpdateBugStatus.CommandType = CommandType.StoredProcedure;
            if (conn.State == ConnectionState.Open)
                conn.Close();
            conn.Open();
            if (cmdUpdateBugStatus.ExecuteNonQuery() > 0)
            {
                updatedBugStatus = true;
            }
            return updatedBugStatus;

        }
        //After clearing the bugs developer returns the status back to tester with particular testerid
        public DataSet GetBugStatusFromDeveloper(string testerId)
        {
            cmdGetBugFixedModuleStatus = new SqlCommand("proc_GetBugStatusFromDeveloper", conn);
            cmdGetBugFixedModuleStatus.Parameters.AddWithValue("@testerId", testerId);
            DataSet dsGetBugStatus = new DataSet();
            daGetBugStatus = new SqlDataAdapter(cmdGetBugFixedModuleStatus);
            daGetBugStatus.SelectCommand.CommandType = CommandType.StoredProcedure;
            daGetBugStatus.Fill(dsGetBugStatus);
            return dsGetBugStatus;
            

        }
        //get Bug details using module id 
        public DataSet GetBugDetails(string moduleId)
        {
            cmdGetBugDetails = new SqlCommand("proc_GetBugDetails", conn);
            cmdGetBugDetails.Parameters.AddWithValue("@moduleId", moduleId);
            DataSet dsGetBugDetails = new DataSet();
            daGetBugDetails = new SqlDataAdapter(cmdGetBugDetails);
            daGetBugDetails.SelectCommand.CommandType = CommandType.StoredProcedure;
            daGetBugDetails.Fill(dsGetBugDetails);
            return dsGetBugDetails;

        }
        

    }
}
