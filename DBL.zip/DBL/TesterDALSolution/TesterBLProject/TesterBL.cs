﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectModelProject;
using TesterDALProject;
using System.Data;

namespace TesterBLProject
{
    public class TesterBL
    {
        TesterDAL tdal;
        public TesterBL()
        {
            tdal = new TesterDAL();
        }
        //Uses List to get all the projects to be tested using projectid,projectname,project Description
        public List<ProjectModel> GetAllTesterProjects(string testerId)
        {
            List<ProjectModel> projects = new List<ProjectModel>();
            DataSet dsGetProject = tdal.GetAllProjectFromManager( testerId);
            ProjectModel project;
            foreach (DataRow row in dsGetProject.Tables[0].Rows)
            {
                project = new ProjectModel();
                project.ProjectId = row[0].ToString();
                project.ProjectName = row[1].ToString();
                project.ProjectDescription = row[2].ToString();
                projects.Add(project);
            }
            return projects;

        }
        //Get all modules to be tested with moduleid,modulename,module description
        public List<ProjectModel> GetAllTesterModules(string projectId)
        {
            List<ProjectModel> modules = new List<ProjectModel>();
            DataSet dsGetModules = tdal.GetAllmodulesForProject(projectId);
            ProjectModel module;
            foreach (DataRow row in dsGetModules.Tables[0].Rows)
            {
                module = new ProjectModel();
                module.ModuleId = row[0].ToString();
                module.ModuleName = row[1].ToString();
                module.ModuleDescription = row[2].ToString();
                modules.Add(module);
            }
            return modules;
        }
        //Tester raises a new bug to developer if there is a bug in a module
        public bool CreateBug(ProjectModel bugValues)
        {
            return tdal.CreateBug(bugValues);
        }
        //Updates the module status to manager 
        public bool UpdateModuleTestedStatustoManager(ProjectModel tester)
        {
            return tdal.UpdateModuleTestedStatustoManager(tester);
        }
        //returns bug status to developer
        public bool UpdateBugStatusToDeveloper(ProjectModel tester)
        {
            return tdal.UpdateBugStatusToDeveloper(tester);
        }
        //Tester get all bugs in a list 
        public List<ProjectModel> GetAllBug(string moduleId)
        {
            List<ProjectModel> bugs = new List<ProjectModel>();
            DataSet dsGetBugDetails = tdal.GetBugDetails(moduleId);
            ProjectModel bug;
            foreach (DataRow row in dsGetBugDetails.Tables[0].Rows)
            {
                bug = new ProjectModel();
                bug.BugId = row[0].ToString();
                bug.ModuleId = row[1].ToString();
                bug.BugDetails = row[2].ToString();
                bugs.Add(bug);
            }
            return bugs;
        }
        //Get Bug status from developer
        public List<ProjectModel> GetBugStatusFromDeveloper(string testerId)
        {
            List<ProjectModel> bugStatus = new List<ProjectModel>();
            DataSet dsGetBugStatus = tdal.GetBugStatusFromDeveloper(testerId);
            ProjectModel bug;
            foreach (DataRow row in dsGetBugStatus.Tables[0].Rows)
            {
                bug = new ProjectModel();
                bug.BugId = row[0].ToString();
                bug.BugStatus = row[1].ToString();
                bugStatus.Add(bug);
            }
            return bugStatus;
        }

    }
}
