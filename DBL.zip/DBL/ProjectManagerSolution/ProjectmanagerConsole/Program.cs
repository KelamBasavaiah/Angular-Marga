﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectManagerBLProject;
using ProjectModelProject;

namespace ProjectmanagerConsole
{
    class Program
    {
        ProjectManagerBL bl = new ProjectManagerBL();
        ProjectModel manager;
        public void project()
        {
            manager = new ProjectModel();
            manager.ManagerId = "E001";
            List<ProjectModel> list = bl.GetAllProjects(manager);
            foreach (ProjectModel item in list)
            {
                Console.WriteLine(item.ProjectId);

            }
        }
        static void Main(string[] args)
        {
            Program program = new Program();
            program.project();
            Console.ReadKey();
        }
    }
}
