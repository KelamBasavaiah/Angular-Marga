﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectManagerProject;
using ProjectModelProject;
using System.Data;

namespace ProjectManagerBLProject
{
    public class ProjectManagerBL
    {
        ProjectManagerDAL dal;
        public ProjectManagerBL()
        {
            dal = new ProjectManagerDAL();
        }
        //Get all projects in a list with project id,name and description
        public List<ProjectModel> GetAllProjects(ProjectModel manager)
        {
            List<ProjectModel> projects = new List<ProjectModel>();
            DataSet dsGetProject = dal.GetAllProjects(manager);
            ProjectModel project;
            foreach (DataRow row in dsGetProject.Tables[0].Rows)
            {
                project = new ProjectModel();
                project.ProjectId = row[0].ToString();
                Console.WriteLine("haii" + project.ProjectId);
                project.ProjectName = row[1].ToString();
                project.ProjectDescription = row[2].ToString();
                projects.Add(project);
            }
            return projects;

        }
        //Get All modules when a particular project selected
        public List<ProjectModel> GetAllTModulesForProject(string Id)
        {
            List<ProjectModel> modules = new List<ProjectModel>();
            DataSet dsGetModules = dal.GetModulesForProject(Id);
            ProjectModel module;
            foreach (DataRow row in dsGetModules.Tables[0].Rows)
            {
                module = new ProjectModel();
                module.ModuleId = row[0].ToString();
                module.ModuleName = row[1].ToString();
                module.ModuleDescription = row[2].ToString();
                modules.Add(module);
            }
            return modules;
        }
        //Manager assign module to developer
        public bool AssignModuleToDeveloper(ProjectModel manager)
        {
            return dal.AssignModuleToDeveloper(manager);
        }
        //Manager assign module to tester
        public bool AssignModuleToTester(ProjectModel manager)
        {
            return dal.AssignModuleToTester(manager);
        }
        //Recieve module status
        public string GetModuleStatus(string moduleId)
        {
            return dal.GetModuleStatus(moduleId);
        }
        //Get All developers in a list to assign project modules
        public List<ProjectModel> GetAllDevelopers()
        {
            List<ProjectModel> developers = new List<ProjectModel>();
            DataSet dsGetAllDevelopers = dal.GetAllDevelopers();
            ProjectModel developer;
            foreach (DataRow row in dsGetAllDevelopers.Tables[0].Rows)
            {
                developer = new ProjectModel();
                developer.DeveloperId = row[0].ToString();

                developers.Add(developer);
            }


            return developers;
        }
        //Get All Testers in a list to assign bug modules
        public List<ProjectModel> GetAllTesters()
        {
            List<ProjectModel> testers = new List<ProjectModel>();
            DataSet dsGetAllTesters = dal.GetAllTesters();
            ProjectModel tester;
            foreach (DataRow row in dsGetAllTesters.Tables[0].Rows)
            {
                tester = new ProjectModel();
                tester.TesterId = row[0].ToString();

                testers.Add(tester);
            }


            return testers;
        }
    }
}
