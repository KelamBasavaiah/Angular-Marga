﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ProjectModelProject;


namespace ProjectManagerProject
{
    public class ProjectManagerDAL
    {
        SqlConnection conn;
        SqlCommand cmdGetAllProjects,cmdGetAllModules,cmdAssignModuleToDeveloper,cmdAssignModuleToTester,cmdGetModuleStatus;
        SqlDataAdapter daGetProject,daGetModules,daGetAllDevelopers,daGetAllTesters;

        public ProjectManagerDAL()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conUser"].ConnectionString);

        }
        //Get all projects with managerid

        public DataSet GetAllProjects(ProjectModel manager)
        {
            cmdGetAllProjects = new SqlCommand("proc_GetAllProjectForManager", conn);
            DataSet dsGetProject = new DataSet();
            cmdGetAllProjects.Parameters.AddWithValue("@managerId", manager.ManagerId);
            daGetProject = new SqlDataAdapter(cmdGetAllProjects);
            daGetProject.SelectCommand.CommandType = CommandType.StoredProcedure;
            daGetProject.Fill(dsGetProject);
            return dsGetProject;
        }
        //Get modules for a particular projectid
        public DataSet GetModulesForProject(string Id)
        {
            cmdGetAllModules = new SqlCommand("proc_GetModulesForManager", conn);
            DataSet dsGetModules = new DataSet();
            cmdGetAllModules.Parameters.AddWithValue("@ProjectId", Id);
            daGetModules = new SqlDataAdapter(cmdGetAllModules);
            daGetModules.SelectCommand.CommandType = CommandType.StoredProcedure;
            daGetModules.Fill(dsGetModules);
            return dsGetModules;
        }
        //get all developers for manager
        public DataSet GetAllDevelopers()
        {
            DataSet dsGetAllDevelopers = new DataSet();
            daGetAllDevelopers = new SqlDataAdapter("proc_GetAllDevelopers",conn);
            daGetAllDevelopers.SelectCommand.CommandType = CommandType.StoredProcedure;
            daGetAllDevelopers.Fill(dsGetAllDevelopers);
            return dsGetAllDevelopers;
        }
        //Get All testers to debug
        public DataSet GetAllTesters()
        {
            DataSet dsGetAllTesters = new DataSet();
            daGetAllTesters = new SqlDataAdapter("proc_GetAllDevelopers", conn);
            daGetAllTesters.SelectCommand.CommandType = CommandType.StoredProcedure;
            daGetAllTesters.Fill(dsGetAllTesters);
            return dsGetAllTesters;
        }
        //Assign module id to developer with unique developer id
        public bool AssignModuleToDeveloper(ProjectModel manager)
        {
            bool assignModuleToDeveloperStatus = false;
            cmdAssignModuleToDeveloper = new SqlCommand("proc_AssignProjecttoDeveloper",conn);
            cmdAssignModuleToDeveloper.Parameters.AddWithValue("@moduleid",manager.ModuleId);
            cmdAssignModuleToDeveloper.Parameters.AddWithValue("@did",manager.DeveloperId);
            cmdAssignModuleToDeveloper.CommandType = CommandType.StoredProcedure;
            if (conn.State == ConnectionState.Open)
                conn.Close();
            conn.Open();
            if (cmdAssignModuleToDeveloper.ExecuteNonQuery() > 0)
            {
                assignModuleToDeveloperStatus = true;
            }
            conn.Close();
            return assignModuleToDeveloperStatus;
        }
        //Assign module to tester if there is a bug
        public bool AssignModuleToTester(ProjectModel manager)
        {
            bool assignModuleToTesterStatus = false;
            cmdAssignModuleToTester = new SqlCommand("proc_AssignProjectToTester",conn);
            cmdAssignModuleToTester.Parameters.AddWithValue("@moduleid",manager.ModuleId);
            cmdAssignModuleToTester.Parameters.AddWithValue("@Tid",manager.TesterId);
            cmdAssignModuleToTester.CommandType = CommandType.StoredProcedure;
            if (conn.State == ConnectionState.Open)
                conn.Close();
            conn.Open();
            if (cmdAssignModuleToTester.ExecuteNonQuery() > 0)
            {
                assignModuleToTesterStatus = true;
            }
            return assignModuleToTesterStatus;
        }
        //Get module status
        public string GetModuleStatus(string moduleId)
        {
            string moduleStatus = "";
            cmdGetModuleStatus = new SqlCommand("proc_GetModuleStatusForManager",conn);
            cmdGetModuleStatus.Parameters.AddWithValue("@moduleId", moduleId);
            cmdGetModuleStatus.CommandType = CommandType.StoredProcedure;
            if (conn.State == ConnectionState.Open)
                conn.Close();
            conn.Open();
            moduleStatus = cmdGetModuleStatus.ExecuteScalar().ToString();
            conn.Close();
           
            return moduleStatus;
        }
        
       

            
    }
}
