﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectModelProject
{
    public class UserDefinedException:ApplicationException
    {
        string myMsg;
        public UserDefinedException()
        {
            myMsg = "No User Data present";
        }
        public override string Message => myMsg;
    }
}
