﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectModelProject
{
    public class ProjectModel
    {
        string employeeId, password, role;
        string projectId, projectName, projectDescription;
        string moduleId, moduleName, moduleDescription;
        string managerId, developerId, testerId;
        string bugId, bugDetails;
        string bugStatus, moduleStatus;

        public string EmployeeId { get => employeeId; set => employeeId = value; }
        public string Password { get => password; set => password = value; }
        public string Role { get => role; set => role = value; }
        public string ProjectId { get => projectId; set => projectId = value; }
        public string ProjectName { get => projectName; set => projectName = value; }
        public string ProjectDescription { get => projectDescription; set => projectDescription = value; }
        public string ManagerId { get => managerId; set => managerId = value; }
        public string DeveloperId { get => developerId; set => developerId = value; }
        public string TesterId { get => testerId; set => testerId = value; }
        public string BugId { get => bugId; set => bugId = value; }
        public string BugDetails { get => bugDetails; set => bugDetails = value; }
        public string BugStatus { get => bugStatus; set => bugStatus = value; }
        public string ModuleStatus { get => moduleStatus; set => moduleStatus = value; }
        public string ModuleId { get => moduleId; set => moduleId = value; }
        public string ModuleName { get => moduleName; set => moduleName = value; }
        public string ModuleDescription { get => moduleDescription; set => moduleDescription = value; }
        
    }
}
