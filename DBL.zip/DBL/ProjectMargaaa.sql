﻿drop database dbMarga;
create database dbMargaProject
use dbMargaProject

-----------------table1 User table--------------------
create table tblUser(Employee_Id varchar(10) constraint pk_employeeid primary key,
Password varchar(20),
Role varchar(20))

select * from tblUser
sp_help tblUser
------------inset values in table 1 login---------------------------------------
insert into tblUser values('E001','1234','Manager')
insert into tblUser values('E002','2341','Developer')
insert into tblUser values('E003','3412','Tester')
insert into tblUser values('E004','4321','Manager')
insert into tblUser values('E005','1324','Developer')
insert into tblUser values('E006','1432','Tester')
insert into tblUser values('E007','1334','Developer')
insert into tblUser values('E008','1439','Tester')
insert into tblUser values('E009','1479','Manager')

select * from tblUser


-------------------------------table 2 Project table------------------------------
create table tblProject(Project_Id varchar(10) constraint pk_project primary key,
Project_Name varchar(20),Description varchar(50))


sp_help tblProject
select * from tblProject
-------------insert table value2--------
insert into tblProject values('P001','Blood Bank App','Requirement of blood group to patients')
insert into tblProject values('P002','Stock Management','info about stocks')
insert into tblProject values('P003','E-Commerce','online Shopping site')
insert into tblProject values('P004','BPO App','Customer')
---------------------------table 3--- project Manager--------
create table tblProjectManager(project_id varchar(10) constraint fk_projectid references tblProject(Project_Id),
manager_id varchar(10)  constraint fk_manager_id foreign key references tblUser(Employee_Id)
constraint pk_ProjectManager primary key (project_id,manager_id))



sp_help tblProjectManager
select * from tblProjectManager
insert into tblProjectManager values('P001','E001')
insert into tblProjectManager values('P002','E004')
insert into tblProjectManager values('P003','E004')
insert into tblProjectManager values('P004','E009')

----------------------------------------table 3----Module table-------------------------
create table tblModuleProject (Module_id varchar(5) constraint fk_Module_Id foreign key references tblModules(Module_Id),
Project_Id varchar(10) constraint fk_ProId foreign key references tblProject(Project_Id),
Developer_Id varchar(10) constraint fk_devid references tblUser(Employee_Id),
Tester_Id varchar(10) constraint fk_testersid references tblUser(Employee_Id))
----------------------------table-------------------------
create table tblModules(Module_Id varchar(5) constraint pk_Module_Id primary key,Module_Name varchar(20),
Description varchar(40))

sp_help tblModules
select * from tblModules

-----inserting--------
insert into tblModules values('MO01','P001','Registration Valid','validating all modules','E002','E003','M001')
insert into tblModules values('MO02','P002','Login Page','User page ','E005','E006','M002')
insert into tblModules values('MO03','P003','Home Page','dashboard for user','E007','E006','M003')
insert into tblModules values('MO04','P004','Master Page','Common layout ','E005','E008','M004')

---------------------------------table 4 ----Bug Table--------------------------------
create table tblBug(Bug_Id varchar(5) constraint pk_bugid primary key,
Modules_Id varchar(5) constraint fk_moduleid references tblModules(Module_Id),
Bug_Details varchar(50))

drop table tblBug
insert into tblBug values('BU01','MO01',' ','B001')
insert into tblBug values('BU02','MO02',' ','B002')
insert into tblBug values('BU03','MO03',' ','B003')
insert into tblBug values('BU04','MO04',' ','B004')

sp_help tblBug
select *from tblBug
-----------------table bug status-------
create table tblBugStatus(BugId varchar(5) constraint fk_Bid foreign key references tblBug(Bug_Id),status varchar(10))
insert into  tblBugStatus values('B001','NC')
insert into  tblBugStatus values('B002','NC')
insert into  tblBugStatus values('B003','NC')
insert into  tblBugStatus values('B004','NC')

----------module status----
create table tblModuleStatus(Module_id varchar(5) constraint fk_Mid foreign key references tblModules(Module_Id),status varchar(10))

insert into tblModuleStatus values('MO01','NC')
insert into tblModuleStatus values('MO02','NC')
insert into tblModuleStatus values('MO03','NC')
insert into tblModuleStatus values('MO04','NC')
delete from tblModuleStatus where Module_id='MO01'

--------------------store procedure------------ProjectManager------------------------------------

create proc proc_AssignProjecttoDeveloper(@moduleid varchar(5),@did varchar(5))
as
begin
update tblModuleProject set Developer_Id = @did where Module_Id = @moduleid
end

create proc proc_AssignProjectToTester(@moduleid varchar(5),@Tid varchar(5))
as
begin
update tblModuleProject set Tester_Id = @Tid where Module_Id = @moduleid
end
exec proc_AssignProjectToTester 'MO01', 'E003'

alter proc proc_GetAllProjectForManager(@managerId varchar(10))
as
begin
select * from tblProject where Project_Id in(select project_id from tblProjectManager where manager_id=@managerId)
end

exec proc_GetAllProjectForManager 'E004'
exec proc_GetModulesForManager 'E001'

alter proc proc_GetModulesForManager(@ProjectId varchar(10))
as
begin
select  * from tblModules where Module_Id in(select Module_id from tblModuleProject where Project_Id=@ProjectId)
end
alter proc proc_GetModuleStatusForManager(@moduleId varchar(10))
as
begin
select status from tblModuleStatus where Module_id=@moduleId 
end
exec proc_GetModuleStatusForManager 'MO01'
-----------------------------------------getAllDevelopers----------
create proc proc_GetAllDevelopers
as
begin
select Employee_Id  from tblUser where Role='Developer'
end
-----------------------getAllTesters------------------------
create proc proc_GetAllTesters
as
begin
select Employee_Id  from tblUser where Role='Tester'
end

delete from tblModuleStatus where Module_id='MO01'
-------------------StoredProcedure---------Tester-------------
create proc proc_GetModuleStatus(@testerId varchar(10))
as
begin
select * from tblModuleStatus where Module_id=(select Module_id from tblModuleProject where Tester_Id=@testerId)
end
-----------------------------------------------------------------------------------
create proc proc_GetAllproject(@testerId varchar(10))
as
begin
select * from tblProject where Project_Id in(select Project_id from tblModuleProject where Tester_Id=@testerId)
end
exec proc_GetAllproject 'E003'
-------------------------------------------------------------------------------------------
alter proc proc_GetAllModules(@ProjectId varchar(10))
as
begin
select * from tblModules where Module_Id in(select Module_id from tblModuleProject where Project_Id=@ProjectId)
end
---------------------------------------------------------------------------------------------------------------------------------------------
alter proc proc_UpdateModuleStatusToManager(@moduleId varchar(10),@moduleStatus varchar(10))
as
begin
update tblModuleStatus set status=@moduleStatus where Module_id=@moduleId
end
-------------------------------------------------------------------------------------------------------------------------
alter proc proc_UpdateBugStatusToDeveloper(@bugId varchar(10),@bugStatus varchar(10))
as
begin
insert into tblBugStatus values(@bugId,@bugStatus)
end

-------------------------------------------------------------------------------------------------------------
create proc proc_CreateBug(@bugId varchar(5),@ModuleId varchar(10),@BugDescription varchar(50))
as
begin
insert into tblBug values(@bugId,@ModuleId,@BugDescription)
end
-------------------------------------------------------------------------------------------
alter proc proc_GetBugStatusFromDeveloper(@testerId varchar(5))
as
begin
select * from tblBugStatus where BugId in  
(select Bug_Id from tblBug where Modules_Id in(select Module_Id from tblModuleProject where Tester_Id=@testerId))
end
exec proc_GetBugStatusFromDeveloper 'E003'

-------------------------------------------DEVELOPER----------------------------------------------------------------------------
create proc proc_GetAllprojectForDeveloper(@developerId varchar(10))
as
begin
select * from tblProject where Project_Id in(select Project_id from tblModuleProject where Developer_Id=@developerId)
end
----------------------------------------------------------------------------------------------------------------------
alter proc proc_GetAllModulesForDeveloper(@ProjectId varchar(10))
as
begin
select * from tblModules where Module_Id in(select Module_id from tblModuleProject where Project_Id=@ProjectId)
end
exec proc_GetAllModulesForDeveloper 'E005'
--------------------------------------------------------------------------------------------------------------------------
alter proc proc_UpdateModuleStatusToManagerFromDeveloper(@moduleId varchar(10),@moduleStatus varchar(10))
as
begin
update tblModuleStatus set status=@moduleStatus where Module_id=@moduleId
end
-------------------------------------------------------------------------------------------------------------------
alter proc proc_UpdateBugStatusToTester(@bug_Id varchar(10),@bugStatus varchar(10))
as
begin
update tblBugStatus set status=@bugStatus where BugId=@bug_Id
end
--------------------------------------------------------------------------------------------------------------------------------
alter proc proc_GetBugStatusFromTester(@developer_Id varchar(10))
as
begin
select * from tblBugStatus where BugId in(select Bug_Id from tblBug where Modules_Id in(select Module_Id from tblModuleProject where Developer_Id=@developer_Id))
end
exec proc_GetBugStatusFromTester 'E002'
----------------------------------------------------------------------------------------------------------------------------
alter proc proc_GetBugDetails(@developerId varchar(10))
as
begin
select * from tblbug where Modules_Id in(select Module_id from tblModuleProject where Developer_Id=@developerId)
end
exec proc_GetBugDetails 'E002'
---------------------------------------------------
create proc proc_GetBugModules(@bug_id varchar(10))
as
begin
select * from tblModules where Module_Id in(select Modules_Id from tblBug where Bug_Id=@bug_id)
end
-------------------------------------------------------------------------
create proc proc_GetBugModulesForTester(@Tester_id varchar(10))
as
begin
select * from tblModules where Module_Id in(select Module_id from tblModuleProject where Tester_Id=@Tester_id)
end
exec proc_GetBugModules 'B001'

----------------------------------------------------------------------------------------------------
create proc proc_userlogin(@EmpID varchar(10),@password varchar(20),@role varchar(20) out) 
as
begin
select @role=Role from tblUser where Employee_Id = @EmpID AND Password = @password
end
select * from tblModules
select * from tblUser
select * from tblModuleProject
select * from tblProjectManager
select * from tblBugStatus
select * from tblbug
select * from tblModuleStatus
select * from tblModules
exec  proc_GetAllProjects 'E001'
exec proc_GetBugStatusFromDeveloper 'E003'
exec proc_AssignProjecttoDeveloper 'MO01','E005'
insert into tblBugStatus values('B001','NC')