﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDALLibrary;
using EmployeeModelLibrary;

namespace EmployeeBLLibrary
{
    public class EmployeeBL
    {
        EmployeeDAL dal;
        public EmployeeBL()
        {
            dal = new EmployeeDAL();
        }
        public bool Login(string Adminusername, string Adminpassword)
        {
            bool loginStatus = false;
            string databasePassword = dal.FetchPassword(Adminusername);
            if (databasePassword == Adminpassword)
                loginStatus = true;
            return loginStatus;
        }
        public List<EmployeeModel> BLGetAllEmployee()
        {
            return dal.GetAllEmployees();
        }

        //web api post or insert
        public EmployeeModel BLInsertEmployee(EmployeeModel employee)
        {
            return dal.InsertEmployee(employee);
        }

        //web api update
        public EmployeeModel BLUpdateEmployee(EmployeeModel employee)
        {
            return dal.UpdateEmployee(employee);
        }

        //web api delete 
        public string BLDeleteEmployee(string employeeid)
        {
            return dal.DeleteEmployee(employeeid);
        }
        //edit
        public List<EmployeeModel> BlGetEditEmployeeData(string EmployeeId)
        {
            return dal.GetEditEmployeeData(EmployeeId);
        }
    }
}
