﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EmployeeBLLibrary;
using EmployeeModelLibrary;
using System.Web.Http.Cors;
using System.Net.Mail;

namespace WebApplication.Controllers
{
    [EnableCors("http://localhost:4200", "*", "GET,POST,PUT,DELETE")]
    public class EmployeeController : ApiController
    {
        EmployeeBL BL = new EmployeeBL();
        static List<EmployeeModel> employeelist = new List<EmployeeModel>();
        static List<EmployeeModel> editemployeelist = new List<EmployeeModel>();
        // GET: api/Employee
        public IEnumerable<EmployeeModel> Get()
        {
            employeelist = BL.BLGetAllEmployee();
            return employeelist;
        }

        // GET: api/Employee/5
        public bool Get(string Adminusername,string Adminpassword)
        {
            return BL.Login(Adminusername, Adminpassword);
        }

        // POST: api/Employee
        public EmployeeModel Post([FromBody]EmployeeModel value)
        {
            if (value != null)
                return BL.BLInsertEmployee(value);
            else
                return new EmployeeModel();
        }

        // PUT: api/Employee/5
        public EmployeeModel Put(string id, [FromBody]EmployeeModel value)
        {
            var employee = (from u in employeelist
                        where u.EmployeeId == id
                        select u).First();
            if (employee != null)
                return BL.BLUpdateEmployee(value);
            else
                return new EmployeeModel();
        }
      
        // DELETE: api/Employee/5
        public string Delete(string employeeid)
        {
           return BL.BLDeleteEmployee(employeeid);
        }
        //Edit
        public IEnumerable<EmployeeModel> GetEditData(string EmployeeId)
        {
            editemployeelist = BL.BlGetEditEmployeeData(EmployeeId);
            return editemployeelist;
        }
    }
}
