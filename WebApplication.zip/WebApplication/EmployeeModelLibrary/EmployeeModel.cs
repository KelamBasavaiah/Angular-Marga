﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeModelLibrary
{
    public class EmployeeModel
    {
        string employeeId,employeeName, email, mobile, userName, password, confirmPassword, role;
        string adminusername, adminpassword;

        public string EmployeeId { get => employeeId; set => employeeId = value; }
        public string EmployeeName { get => employeeName; set => employeeName = value; }
        public string Email { get => email; set => email = value; }
        public string Mobile { get => mobile; set => mobile = value; }
        public string UserName { get => userName; set => userName = value; }
        public string Password { get => password; set => password = value; }
        public string ConfirmPassword { get => confirmPassword; set => confirmPassword = value; }
        public string Role { get => role; set => role = value; }
        public string Adminusername { get => adminusername; set => adminusername = value; }
        public string Adminpassword { get => adminpassword; set => adminpassword = value; }

    }
}
