﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeModelLibrary
{
    public class NoUserInDatabaseException:ApplicationException
    {
        string myMsg;
        public NoUserInDatabaseException()
        {
            myMsg = "No Login data present";
        }
        public override string Message => myMsg;
    }
}
