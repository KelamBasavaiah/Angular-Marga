﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeModelLibrary;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EmployeeDALLibrary
{
    public class EmployeeDAL
    {
        SqlConnection conn;
        SqlCommand cmdFetchPassword, cmdFetchEmployee, cmdInsertEmployee, cmdUpdateEmployee, cmdDeleteEmployee,cmdEditEmployeeData;
        public EmployeeDAL()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conUser"].ConnectionString);
        }
        public string FetchPassword(string Adminusername)
        {
            cmdFetchPassword = new SqlCommand("proc_Login", conn);
            cmdFetchPassword.Parameters.Add("@UserName", SqlDbType.VarChar, 50);
            cmdFetchPassword.Parameters.Add("@Password", SqlDbType.VarChar, 50);
            cmdFetchPassword.CommandType = CommandType.StoredProcedure;

            string Adminpassword = null;
            openConnection();
            conn.Open();
            cmdFetchPassword.Parameters[0].Value = Adminusername;
            cmdFetchPassword.Parameters[1].Direction = ParameterDirection.Output;
            cmdFetchPassword.ExecuteNonQuery();
            Adminpassword = cmdFetchPassword.Parameters[1].Value.ToString();
            conn.Close();
            return Adminpassword;

        }
        public List<EmployeeModel> GetAllEmployees()
        {
            cmdFetchEmployee = new SqlCommand("proc_GetAllEmployee", conn);
            cmdFetchEmployee.CommandType = CommandType.StoredProcedure;

            List<EmployeeModel> employeeslist = new List<EmployeeModel>();
            openConnection();
            conn.Open();
            SqlDataReader drUsers = cmdFetchEmployee.ExecuteReader();
            //if (drUsers.HasRows == false)
            //    throw new NoUserInDatabaseException();
            EmployeeModel employee = null;
            while (drUsers.Read())
            {
                employee = new EmployeeModel();
                employee.EmployeeId = drUsers[0].ToString();
                employee.EmployeeName = drUsers[1].ToString();
                employee.Email = drUsers[2].ToString();
                employee.Mobile = drUsers[3].ToString();
                employee.UserName = drUsers[4].ToString();
                employee.Password = drUsers[5].ToString();
                employee.ConfirmPassword = drUsers[6].ToString();
                employee.Role = drUsers[7].ToString();
                employeeslist.Add(employee);

            }
            conn.Close();
            return employeeslist;
        }
        public EmployeeModel InsertEmployee(EmployeeModel employee)
        {
            try
            {
                cmdInsertEmployee = new SqlCommand("proc_InsertEmployee", conn);
                cmdInsertEmployee.CommandType = CommandType.StoredProcedure;

                cmdInsertEmployee.Parameters.AddWithValue("@EmployeeId", employee.EmployeeId);
                cmdInsertEmployee.Parameters.AddWithValue("@EmployeeName", employee.EmployeeName);
                cmdInsertEmployee.Parameters.AddWithValue("@Email", employee.Email);
                cmdInsertEmployee.Parameters.AddWithValue("@Mobile", employee.Mobile);
                cmdInsertEmployee.Parameters.AddWithValue("@UserName", employee.UserName);
                cmdInsertEmployee.Parameters.AddWithValue("@Password", employee.Password);
                cmdInsertEmployee.Parameters.AddWithValue("@confirmPassword", employee.ConfirmPassword);
                cmdInsertEmployee.Parameters.AddWithValue("@Role", employee.Role);
                openConnection();
                conn.Open();
                if (!(cmdInsertEmployee.ExecuteNonQuery() > 0))
                    employee = null;
            }
            catch (SqlException se)
            {
                Console.WriteLine("Employee Id Already Existed!!");
                employee = null;
            }
            finally
            {
                conn.Close();
            }
            return employee;
        }
        //public EmployeeModel InsertEmployee(EmployeeModel employee)
        //{
        //    cmdInsertEmployee = new SqlCommand("proc_InsertEmployee", conn);
        //    cmdInsertEmployee.CommandType = CommandType.StoredProcedure;

        //    cmdInsertEmployee.Parameters.AddWithValue("@EmployeeId", employee.EmployeeId);
        //    cmdInsertEmployee.Parameters.AddWithValue("@EmployeeName", employee.EmployeeName);
        //    cmdInsertEmployee.Parameters.AddWithValue("@Email", employee.Email);
        //    cmdInsertEmployee.Parameters.AddWithValue("@Mobile", employee.Mobile);
        //    cmdInsertEmployee.Parameters.AddWithValue("@UserName", employee.UserName);
        //    cmdInsertEmployee.Parameters.AddWithValue("@Password", employee.Password);
        //    cmdInsertEmployee.Parameters.AddWithValue("@confirmPassword", employee.ConfirmPassword);
        //    cmdInsertEmployee.Parameters.AddWithValue("@Role", employee.Role);
        //    openConnection();
        //    conn.Open();
        //    if (!(cmdInsertEmployee.ExecuteNonQuery() > 0))
        //        employee = null;
        //    return employee;
        //}
        public EmployeeModel UpdateEmployee(EmployeeModel employee)
        {
            cmdUpdateEmployee = new SqlCommand("proc_UpdateEmployee", conn);
            cmdUpdateEmployee.CommandType = CommandType.StoredProcedure;

            cmdUpdateEmployee.Parameters.AddWithValue("@EmployeeId", employee.EmployeeId);
            cmdUpdateEmployee.Parameters.AddWithValue("@EmployeeName", employee.EmployeeName);
            cmdUpdateEmployee.Parameters.AddWithValue("@Email", employee.Email);
            cmdUpdateEmployee.Parameters.AddWithValue("@Mobile", employee.Mobile);
            cmdUpdateEmployee.Parameters.AddWithValue("@UserName", employee.UserName);
            cmdUpdateEmployee.Parameters.AddWithValue("@Password", employee.Password);
            cmdUpdateEmployee.Parameters.AddWithValue("@confirmPassword", employee.ConfirmPassword);
            cmdUpdateEmployee.Parameters.AddWithValue("@Role", employee.Role);
            openConnection();
            conn.Open();
            if (!(cmdUpdateEmployee.ExecuteNonQuery() > 0))
                employee = null;
            return employee;
        }
        public string DeleteEmployee(string EmployeeId)
        {
            cmdDeleteEmployee = new SqlCommand("proc_DeleteEmployee", conn);
            cmdDeleteEmployee.Parameters.AddWithValue("@EmployeeId", EmployeeId);
            cmdDeleteEmployee.CommandType = CommandType.StoredProcedure;
            openConnection();
            conn.Open();
            if (cmdDeleteEmployee.ExecuteNonQuery() > 0)
            {
                conn.Close();
                return "Deleted";
            }
            else
            {
                conn.Close();
                return "Not Deleted";
            }
        }
        public void openConnection()
        {
            if (conn.State != ConnectionState.Closed)
                conn.Close();
        }

        public List<EmployeeModel> GetEditEmployeeData(string EmployeeId)
        {
            cmdEditEmployeeData = new SqlCommand("proc_GetEditEmployeeData", conn);
            cmdEditEmployeeData.Parameters.AddWithValue("@EmployeeId", EmployeeId);
            cmdEditEmployeeData.CommandType = CommandType.StoredProcedure;

            List<EmployeeModel> editemployeelist = new List<EmployeeModel>();
            openConnection();
            conn.Open();
            SqlDataReader drUsers = cmdEditEmployeeData.ExecuteReader();
            if (drUsers.HasRows == false)
                throw new NoUserInDatabaseException();
            EmployeeModel employee = null;
            while (drUsers.Read())
            {
                employee = new EmployeeModel();
                employee.EmployeeId = drUsers[0].ToString();
                employee.EmployeeName = drUsers[1].ToString();
                employee.Email = drUsers[2].ToString();
                employee.Mobile = drUsers[3].ToString();
                employee.UserName = drUsers[4].ToString();
                employee.Password = drUsers[5].ToString();
                employee.ConfirmPassword = drUsers[6].ToString();
                employee.Role = drUsers[7].ToString();
                editemployeelist.Add(employee);
            }
            conn.Close();
            return editemployeelist;
        }
    }
}
